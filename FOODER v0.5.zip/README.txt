Fooder Apps v0.5b
oleh:
Adam Rosyad				(16.41010.0092);
Fadilah Alfan W				(16.41010.0109);
Rachmad Sandy Hikawan			(16.41010.0088);
Ramadhany Krismaliq S			(16.41010.0084);

Nama DB: Fooder(fooder.sql)
Nama Class Utama: home.java
User/Pass Admin: admin/admin
Tipe ZIP: Export Project from Netbeans 8.2
