/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FOODER;

/**
 *
 * @author Adm-Dhan
 */
public class makanan {
    private int Id_Makanan;
    private String Nama_Makanan;
    private int Harga;

    public makanan(String Nama_Makanan, int Harga) {
        this.Nama_Makanan = Nama_Makanan;
        this.Harga = Harga;
    }

    public makanan(int Id_Makanan, String Nama_Makanan, int Harga) {
        this.Id_Makanan = Id_Makanan;
        this.Nama_Makanan = Nama_Makanan;
        this.Harga = Harga;
    }

    public int getId_Makanan() {
        return Id_Makanan;
    }

    public String getNama_Makanan() {
        return Nama_Makanan;
    }

    public int getHarga() {
        return Harga;
    }
    
}
