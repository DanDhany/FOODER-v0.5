/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FOODER;

/**
 *
 * @author Adm-Dhan
 */
public class cart {
    private String id_order, no_meja, menu;
    private int jml_pesanan, harga, tot_harga;

    public cart(String id_order, String no_meja, String menu, int jml_pesanan, int harga, int tot_harga) {
        this.id_order = id_order;
        this.no_meja = no_meja;
        this.menu = menu;
        this.jml_pesanan = jml_pesanan;
        this.harga = harga;
        this.tot_harga = tot_harga;
    }

    public String getId_order() {
        return id_order;
    }

    public String getNo_meja() {
        return no_meja;
    }

    public String getMenu() {
        return menu;
    }

    public int getJml_pesanan() {
        return jml_pesanan;
    }

    public int getHarga() {
        return harga;
    }

    public int getTot_harga() {
        return tot_harga;
    }
    
    
}
