
package FOODER;

import com.mysql.jdbc.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


    public class pengunjung {
        private String ID;
        private String Nama;
        private String Alamat;
        private String Tgl;
        private String Telp;

    public pengunjung(String ID, String Nama, String Alamat, String Tgl, String Telp) {
        this.ID = ID;
        this.Nama = Nama;
        this.Alamat = Alamat;
        this.Tgl = Tgl;
        this.Telp = Telp;
    }

    public String getID() {
        return ID;
    }

    public String getNama() {
        return Nama;
    }

    public String getAlamat() {
        return Alamat;
    }

    public String getTgl() {
        return Tgl;
    }

    public String getTelp() {
        return Telp;
    }


        
        
}
