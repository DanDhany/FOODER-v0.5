/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FOODER;

/**
 *
 * @author Adm-Dhan
 */
public class minuman {
    private int Id_minuman;
    private String Nama_Minuman;
    private int  Harga;

    public minuman(String Nama_Minuman, int Harga) {
        this.Nama_Minuman = Nama_Minuman;
        this.Harga = Harga;
    }
    
    

    public minuman(int Id_minuman, String Nama_Minuman, int Harga) {
        this.Id_minuman = Id_minuman;
        this.Nama_Minuman = Nama_Minuman;
        this.Harga = Harga;
    }
    
    

    public int getId_minuman() {
        return Id_minuman;
    }

    public int getHarga() {
        return Harga;
    }

    public String getNama_Minuman() {
        return Nama_Minuman;
    }
    
}
