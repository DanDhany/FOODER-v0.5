/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FOODER;

import com.mysql.jdbc.Driver;
import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Adm-Dhan
 */
public class menuMinum extends javax.swing.JFrame {
private String mkn;
    /**
     * Creates new form menuMakan
     */
    public menuMinum() {
        initComponents();
          Show_Menu_In_JTable();
          Show_Item_In_JTable();
          AutoNumber();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        txtJmlMkn = new javax.swing.JTextField();
        btnUpdate = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        btnKembali = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        txtTotal = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtMenu = new javax.swing.JTextField();
        txtHrg = new javax.swing.JTextField();
        txtNoMeja = new javax.swing.JTextField();
        txtOrderID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        BG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nama Makanan");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 480, -1, -1));

        txtJmlMkn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtJmlMknKeyPressed(evt);
            }
        });
        getContentPane().add(txtJmlMkn, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 550, 41, 30));

        btnUpdate.setBackground(new java.awt.Color(255, 255, 255));
        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/update.png"))); // NOI18N
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        getContentPane().add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 500, 110, 40));

        btnSimpan.setBackground(new java.awt.Color(255, 255, 255));
        btnSimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/simpan menu.png"))); // NOI18N
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });
        getContentPane().add(btnSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 540, 110, 40));

        btnKembali.setBackground(new java.awt.Color(255, 255, 255));
        btnKembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/kembali.png"))); // NOI18N
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });
        getContentPane().add(btnKembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 540, 110, 40));

        btnHapus.setBackground(new java.awt.Color(255, 255, 255));
        btnHapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/Hapus.png"))); // NOI18N
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });
        getContentPane().add(btnHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 500, 110, 40));

        txtTotal.setEditable(false);
        getContentPane().add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 550, 110, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "OrderID", "Menu", "Porsi"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 210, 330));

        txtMenu.setEditable(false);
        getContentPane().add(txtMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 480, 160, 30));

        txtHrg.setEditable(false);
        getContentPane().add(txtHrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 510, 80, 30));

        txtNoMeja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNoMejaActionPerformed(evt);
            }
        });
        getContentPane().add(txtNoMeja, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 440, 50, 30));

        txtOrderID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtOrderIDKeyPressed(evt);
            }
        });
        getContentPane().add(txtOrderID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 440, 41, 30));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("No. Meja");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 450, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Jumlah Pesan");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 550, -1, -1));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Rp.");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, -1, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Order ID.");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 450, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Menu", "Hrg/porsi"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.getTableHeader().setReorderingAllowed(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 480, 270));

        BG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Menu Minuman800.png"))); // NOI18N
        getContentPane().add(BG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
private static void pesan_kosong(){
    JOptionPane.showMessageDialog(null, "Nomor Meja, dan Jumlah Porsi Belum Dimasukan!", "PERINGATAN!", JOptionPane.WARNING_MESSAGE);
}
private static void pesan_karakter(){
    JOptionPane.showMessageDialog(null, "Inputan Harus Angka!", "PERINGATAN!", JOptionPane.WARNING_MESSAGE);
}
    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        if (txtJmlMkn.getText().toString().equals("")&&txtNoMeja.getText().toString().equals("")){
        pesan_kosong();
        }else {
        int hrg=Integer.valueOf(txtHrg.getText());
        int hrgJml=Integer.valueOf(txtJmlMkn.getText());
        int hrgTot = hrg*hrgJml;
        
        String query = "UPDATE `cart` SET `id_order`='"+txtOrderID.getText()+"',`no_meja`='"+txtNoMeja.getText()+"',`menu`='"+txtMenu.getText()+"',`jml_pesanan`='"+hrgJml+"',`harga`='"+hrg+"',`tot_harga`='"+hrgTot+"' WHERE `id_order`='"+txtOrderID.getText()+"'";
        executeSQlQuery(query, "Updated");
        reset();
        AutoNumber();
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        MainMenu a = new MainMenu();
        a.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        
        String query = "DELETE FROM `cart` WHERE `id_order`='"+txtOrderID.getText()+"'";
        executeSQlQuery(query, "Deleted");
        reset();
        AutoNumber();

    }//GEN-LAST:event_btnHapusActionPerformed

    public void reset(){
        txtOrderID.setText("");
        txtMenu.setText("");
        txtJmlMkn.setText("");
        txtHrg.setText("");
    }

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        
        if (txtJmlMkn.getText().toString().equals("") && txtNoMeja.getText().toString().equals("")){
        pesan_kosong();
        } else {
        int hrg=Integer.valueOf(txtHrg.getText());
        int hrgJml=Integer.valueOf(txtJmlMkn.getText());
        int hrgTot = hrg*hrgJml;
        String query = "INSERT INTO `cart`(`id_order`, `no_meja`, `menu`, `jml_pesanan`, `harga`, `tot_harga`) VALUES ('"+txtOrderID.getText()+"','"+txtNoMeja.getText()+"','"+txtMenu.getText()+"','"+hrgJml+"','"+hrg+"','"+hrgTot+"')";
        executeSQlQuery(query, "Inserted");
        reset();
        AutoNumber();
        }
       
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void txtNoMejaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNoMejaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNoMejaActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        int i = jTable2.getSelectedRow();
        TableModel model = jTable2.getModel();
        txtMenu.setText(model.getValueAt(i,0).toString());
        txtHrg.setText(model.getValueAt(i,1).toString());
        txtJmlMkn.setEditable(true);
        txtJmlMkn.requestFocus();
        txtJmlMkn.setText("1");
        AutoNumber();
        
    }//GEN-LAST:event_jTable2MouseClicked
    private String str = "Rp. ";
    private void txtJmlMknKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtJmlMknKeyPressed
        int hrg=Integer.valueOf(txtHrg.getText());
        int hrgJml=Integer.valueOf(txtJmlMkn.getText());
        int hrgTot = hrg*hrgJml;
        txtTotal.setText(str+hrgTot);
    }//GEN-LAST:event_txtJmlMknKeyPressed

    private void txtOrderIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtOrderIDKeyPressed
        
    }//GEN-LAST:event_txtOrderIDKeyPressed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int a = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        int b = jTable1.getSelectedRow();
        TableModel model1 = jTable2.getModel();
        txtOrderID.setText(model.getValueAt(a,0).toString());
        txtMenu.setText(model.getValueAt(a,1).toString());
        txtJmlMkn.setText(model.getValueAt(a,2).toString());
        txtHrg.setText(model1.getValueAt(b,1).toString());
        txtJmlMkn.setEditable(true);
        txtJmlMkn.requestFocus();
    }//GEN-LAST:event_jTable1MouseClicked
    public Connection getConnection(){
    Connection conn;
    try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooder", "root", "");
            return conn;
        } catch (SQLException e) {
            return null;
        }
    }
    public void AutoNumber() {
        try{
        Connection connection = getConnection();
        Statement state = (Statement) connection.createStatement();
        String sql = "select max(id_order) from cart";
        ResultSet rs = state.executeQuery(sql);
         while(rs.next()){
             int a = rs.getInt(1);
            txtOrderID.setText("00"+Integer.toString(a+1));
        rs.close();
        connection.close();
        }}
        catch(Exception e){
        }
        }
     public void executeSQlQuery(String query, String message)
   {
       Connection con = getConnection();
       Statement st;
       try{
           st = (Statement) con.createStatement();
           if((st.executeUpdate(query)) == 1)
           {
               DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               model.setRowCount(0);
               Show_Item_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data "+message+" Succefully");
           }else{
               JOptionPane.showMessageDialog(null, "Data Not "+message);
           }
       }catch(HeadlessException | SQLException ex){
       }
   }
     public void Show_Item_In_JTable()
   {
       ArrayList<cart> list = getItemsList();
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       Object[] row = new Object[3];
       for(int i = 0; i < list.size(); i++)
       {

           row[0] = list.get(i).getId_order();
           row[1] = list.get(i).getMenu();
           row[2] = list.get(i).getJml_pesanan();


           
           model.addRow(row);
       }
    }
    public ArrayList<cart> getItemsList()
   {
       ArrayList<cart> itemsList = new ArrayList<>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  `cart` ";
       Statement st;
       ResultSet rs;
       
       try {
           st = (Statement) connection.createStatement();
           rs = st.executeQuery(query);

           cart item;

           while(rs.next())
           {
        item = new cart(rs.getString("id_order"),rs.getString("no_meja"),rs.getString("menu"),rs.getInt("jml_pesanan"),rs.getInt("harga"),rs.getInt("tot_harga"));
               itemsList.add(item);
           }

       } 
      catch (SQLException e) {
       }
       return itemsList;
   }
    public void Show_Menu_In_JTable()
   {
       ArrayList<minuman> list = getMenuList();
       DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
       Object[] row = new Object[2];
       for(int i = 0; i < list.size(); i++)
       {

           row[0] = list.get(i).getNama_Minuman();
           row[1] = list.get(i).getHarga();
           
           model.addRow(row);
       }
    }
    
    public ArrayList<minuman> getMenuList()
   {
       ArrayList<minuman> menuList = new ArrayList<>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  `minuman` ";
       Statement st;
       ResultSet rs;
       
       try {
           st = (Statement) connection.createStatement();
           rs = st.executeQuery(query);

           minuman item;

           while(rs.next())
           {
        item = new minuman (rs.getString("Nama_Minuman"),rs.getInt("Harga"));
               menuList.add(item);
           }

       } 
      catch (SQLException e) {
       }
       return menuList;
   }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuMinum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuMinum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuMinum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuMinum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuMinum().setVisible(true);
            }
        });
    }

    public JTextField getTxtHrg1() {
        return txtMenu;
    }

    public JTextField getTxtHrg2() {
        return txtHrg;
    }

    

    public JTextField getTxtTotal() {
        return txtTotal;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BG;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField txtHrg;
    private javax.swing.JTextField txtJmlMkn;
    private javax.swing.JTextField txtMenu;
    private javax.swing.JTextField txtNoMeja;
    private javax.swing.JTextField txtOrderID;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
